# Arquitectura src dura

Este paquete elimina por completo la carpeta `js/` y la capa `src/legacy/`.

El entrypoint del navegador queda en:

```html
<script type="module" src="./src/app/main.js"></script>
```

La frontera arquitectónica es híbrida:

- ECS para entidades simuladas del mundo: jugador, criaturas, proyectiles, puertas, trampas, ítems tirados, áreas de efecto, cuerpos segmentados, facciones, visión, colisiones y cooldowns.
- Módulos normales para app, bootstrap, input físico, UI, render base, definiciones de contenido, guardado, generación de mapas y configuración.

La lógica jugable fue movida a carpetas reales de `src/` según responsabilidad; no quedan wrappers desde `js/` ni imports hacia `src/legacy/`.

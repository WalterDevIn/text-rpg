import { Component } from "../ecs/components.js";
import { ecsWorld } from "../ecs/entityManager.js";
import { isEntityVisibleToPlayer, getVisibleTileKeysForPlayer } from "../world/map.js";

export function updateVisionComponents() {
  const playerEntity = ecsWorld.getEntity("player:player");
  if (!playerEntity?.components?.[Component.POSITION]) return;

  const viewer = {
    x: playerEntity.components[Component.POSITION].x,
    y: playerEntity.components[Component.POSITION].y,
  };

  const visibleTileKeys = getVisibleTileKeysForPlayer(viewer);

  for (const entity of ecsWorld.query(Component.POSITION)) {
    const position = entity.components[Component.POSITION];
    const visible = isEntityVisibleToPlayer(position, viewer);
    ecsWorld.addComponent(entity.id, Component.VISIBLE, { value: visible, visibleTileKeys });
  }
}

export * from "../world/map.js";

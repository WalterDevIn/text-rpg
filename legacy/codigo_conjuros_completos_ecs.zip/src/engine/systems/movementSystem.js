import { Component } from "../ecs/components.js";
import { ecsWorld } from "../ecs/entityManager.js";
import { getLegacyObjectsFromEntities } from "../ecs/legacyBridge.js";
import { getMovementBlockers as queryMovementBlockers } from "../ecs/queries.js";
import { moveEntityWithCollision, normalizeVector } from "../world/collision.js";

export function getMovementBlockerLegacyObjects(options = {}) {
  const excludeIds = new Set(options.excludeEntityIds ?? []);
  const blockers = queryMovementBlockers().filter((entity) => !excludeIds.has(entity.id));
  return getLegacyObjectsFromEntities(blockers);
}

export function moveEcsEntityWithCollision(entity, nextX, nextY, options = {}) {
  const legacy = entity.components.legacyRef?.ref;
  if (!legacy) return false;

  const blockers = options.blockers ?? getMovementBlockerLegacyObjects({ excludeEntityIds: [entity.id] });
  moveEntityWithCollision(legacy, nextX, nextY, { blockers });

  entity.components.position = { x: legacy.x, y: legacy.y };
  return true;
}

export function updateVelocityMovement(deltaTime) {
  for (const entity of ecsWorld.query([Component.POSITION, Component.VELOCITY])) {
    if (entity.components.playerControlled || entity.components.ai || entity.components.projectile) continue;

    const position = entity.components.position;
    const velocity = entity.components.velocity;
    const nextX = position.x + velocity.x * deltaTime;
    const nextY = position.y + velocity.y * deltaTime;

    if (entity.components.collider?.blocksMovement) {
      moveEcsEntityWithCollision(entity, nextX, nextY);
    } else {
      position.x = nextX;
      position.y = nextY;
    }
  }
}

export { moveEntityWithCollision, normalizeVector };
export * from "../world/collision.js";

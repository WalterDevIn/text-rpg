import { Component } from "../ecs/components.js";
import { ecsWorld } from "../ecs/entityManager.js";
import { projectiles as legacyProjectiles } from "../projectiles/projectileSystem.js";

export function updateProjectileLifetimeEcs(dt) {
  for (const entity of ecsWorld.query(Component.PROJECTILE, Component.LIFETIME)) {
    const lifetime = entity.components[Component.LIFETIME];
    lifetime.remainingMs -= dt * 1000;
    if (lifetime.remainingMs <= 0) {
      ecsWorld.destroyEntity(entity.id);
    }
  }
}

export function getProjectileLegacyObjects() {
  return legacyProjectiles;
}

export * from "../projectiles/projectileSystem.js";

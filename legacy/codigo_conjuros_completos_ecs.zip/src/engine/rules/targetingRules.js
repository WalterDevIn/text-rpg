export * from "../../content/spells/spellGeometry.js";

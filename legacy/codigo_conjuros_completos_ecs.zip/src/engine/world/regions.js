export { getCurrentRegionForEntity } from "./map.js";

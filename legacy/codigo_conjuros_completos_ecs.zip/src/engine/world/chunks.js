export const DEFAULT_CHUNK_SIZE = 32;

export function getChunkKey(chunkX, chunkY) {
  return `${chunkX},${chunkY}`;
}

export function worldTileToChunk(tileCol, tileRow, chunkSize = DEFAULT_CHUNK_SIZE) {
  return {
    chunkX: Math.floor(tileCol / chunkSize),
    chunkY: Math.floor(tileRow / chunkSize),
    localCol: ((tileCol % chunkSize) + chunkSize) % chunkSize,
    localRow: ((tileRow % chunkSize) + chunkSize) % chunkSize,
  };
}

export function createChunk(chunkX, chunkY, chunkSize = DEFAULT_CHUNK_SIZE, fillTile = ".") {
  return {
    key: getChunkKey(chunkX, chunkY),
    chunkX,
    chunkY,
    width: chunkSize,
    height: chunkSize,
    tiles: Array.from({ length: chunkSize }, () => Array.from({ length: chunkSize }, () => fillTile)),
  };
}

# ECS híbrido

La ECS se usa sólo para objetos vivos de simulación: jugador, criaturas, proyectiles, puertas, trampas, ítems tirados, áreas de efecto, estados, facciones, visión, colisión y cooldowns.

- `components.js`: nombres y constructores de componentes.
- `entityManager.js`: almacenamiento de entidades.
- `queries.js`: consultas frecuentes.
- `factories.js`: conversión desde objetos de simulación existentes.
- `legacyBridge.js`: puente temporal entre componentes ECS y objetos de simulación que todavía usan UI/render antiguos.
- `simulationFactories.js`: fábricas ECS para entidades nuevas.

Regla: las features nuevas deberían leer/escribir componentes. UI, render base, input físico, definiciones y guardado no se convierten en entidades ECS.

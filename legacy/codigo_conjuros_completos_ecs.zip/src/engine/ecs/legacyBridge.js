import { Component } from "./components.js";
import { ecsWorld } from "./entityManager.js";
import {
  componentsFromLegacyChest,
  componentsFromLegacyEnemy,
  componentsFromLegacyItem,
  componentsFromLegacyMerchant,
  componentsFromLegacyPlayer,
  componentsFromLegacyProjectile,
  entityIdForLegacy,
  pruneUndefinedComponents,
} from "./factories.js";

const SOURCE_TO_FACTORY = {
  player: componentsFromLegacyPlayer,
  enemy: componentsFromLegacyEnemy,
  merchant: componentsFromLegacyMerchant,
  projectile: componentsFromLegacyProjectile,
  item: componentsFromLegacyItem,
  chest: componentsFromLegacyChest,
};

let runtimeCollections = null;
let frameNumber = 0;

export function initializeHybridEcsRuntime(collections) {
  runtimeCollections = collections;
  ecsWorld.clear();
  syncLegacyCollectionsToEcs(collections);
}

export function getHybridEcsRuntime() {
  return {
    ecsWorld,
    frameNumber,
    collections: runtimeCollections,
  };
}

export function beginHybridEcsFrame() {
  frameNumber += 1;
  if (runtimeCollections) {
    syncLegacyCollectionsToEcs(runtimeCollections);
  }
}

export function endHybridEcsFrame() {
  if (runtimeCollections) {
    syncLegacyCollectionsToEcs(runtimeCollections);
    syncEcsComponentsBackToLegacy();
    removeStaleLegacyEntities(runtimeCollections);
  }
}

export function syncLegacyCollectionsToEcs(collections = runtimeCollections) {
  if (!collections) return;

  if (collections.player) upsertLegacyObject("player", collections.player);
  for (const enemy of collections.enemies ?? []) upsertLegacyObject("enemy", enemy);
  for (const merchant of collections.merchants ?? []) upsertLegacyObject("merchant", merchant);
  for (const projectile of collections.projectiles ?? []) upsertLegacyObject("projectile", projectile);
  for (const item of collections.groundItems ?? []) upsertLegacyObject("item", item);
  for (const chest of collections.chests ?? []) upsertLegacyObject("chest", chest);
}

export function upsertLegacyObject(sourceType, legacyObject) {
  if (!legacyObject) return null;

  const factory = SOURCE_TO_FACTORY[sourceType];
  if (!factory) throw new Error(`No ECS factory registered for source type: ${sourceType}`);

  const id = entityIdForLegacy(sourceType, legacyObject);
  const components = pruneUndefinedComponents(factory(legacyObject));
  const entity = ecsWorld.upsert(id, components);
  entity.components[Component.LEGACY_REF].lastSeenFrame = frameNumber;
  return entity;
}

export function removeStaleLegacyEntities(collections = runtimeCollections) {
  if (!collections) return;

  const liveIds = new Set();
  if (collections.player) liveIds.add(entityIdForLegacy("player", collections.player));
  for (const enemy of collections.enemies ?? []) liveIds.add(entityIdForLegacy("enemy", enemy));
  for (const merchant of collections.merchants ?? []) liveIds.add(entityIdForLegacy("merchant", merchant));
  for (const projectile of collections.projectiles ?? []) liveIds.add(entityIdForLegacy("projectile", projectile));
  for (const item of collections.groundItems ?? []) liveIds.add(entityIdForLegacy("item", item));
  for (const chest of collections.chests ?? []) liveIds.add(entityIdForLegacy("chest", chest));

  for (const entity of ecsWorld.query([Component.LEGACY_REF])) {
    const sourceType = entity.components.legacyRef.sourceType;
    if (["player", "enemy", "merchant", "projectile", "item", "chest"].includes(sourceType) && !liveIds.has(entity.id)) {
      ecsWorld.remove(entity.id);
    }
  }
}

export function syncEcsComponentsBackToLegacy() {
  for (const entity of ecsWorld.query([Component.LEGACY_REF])) {
    const legacy = entity.components.legacyRef.ref;
    if (!legacy) continue;

    const position = entity.components.position;
    if (position) {
      legacy.x = position.x;
      legacy.y = position.y;
    }

    const previousPosition = entity.components.previousPosition;
    if (previousPosition) {
      legacy.previousX = previousPosition.x;
      legacy.previousY = previousPosition.y;
    }

    const orientation = entity.components.orientation;
    if (orientation && "angle" in orientation) {
      legacy.angle = orientation.angle;
    }

    const health = entity.components.health;
    if (health) {
      legacy.hp = health.current;
      legacy.maxHp = health.max;
    }

    const renderable = entity.components.renderable;
    if (renderable) {
      if (renderable.char != null) legacy.char = renderable.char;
      if (renderable.color != null) legacy.color = renderable.color;
      if (renderable.baseColor != null) legacy.baseColor = renderable.baseColor;
      if (renderable.drawSize != null) legacy.drawSize = renderable.drawSize;
    }

    const collider = entity.components.collider;
    if (collider && collider.radius != null) {
      legacy.radius = collider.radius;
    }

    const ai = entity.components.ai;
    if (ai) {
      if (ai.state != null) legacy.state = ai.state;
      if (ai.hasSeenPlayer != null) legacy.hasSeenPlayer = ai.hasSeenPlayer;
      if (ai.lastKnownPlayerPosition !== undefined) legacy.lastKnownPlayerPosition = ai.lastKnownPlayerPosition;
      if (ai.path !== undefined) legacy.path = ai.path;
      if (ai.pathTargetTileKey !== undefined) legacy.pathTargetTileKey = ai.pathTargetTileKey;
      if (ai.pathRecalcRemaining !== undefined) legacy.pathRecalcRemaining = ai.pathRecalcRemaining;
    }

    const projectile = entity.components.projectile;
    if (projectile) {
      if (projectile.alive != null) legacy.alive = projectile.alive;
      if (projectile.delay != null) legacy.delay = projectile.delay;
      if (projectile.remainingDistance !== undefined) legacy.remainingDistance = projectile.remainingDistance;
      if (projectile.speed != null) legacy.speed = projectile.speed;
      if (projectile.maxSpeed != null) legacy.maxSpeed = projectile.maxSpeed;
      if (projectile.turnSpeed != null) legacy.turnSpeed = projectile.turnSpeed;
    }

    const lifetime = entity.components.lifetime;
    if (lifetime && lifetime.remaining != null) {
      legacy.lifetime = lifetime.remaining;
    }

    const bouncy = entity.components.bouncy;
    if (bouncy && bouncy.remainingBounces != null) {
      legacy.remainingBounces = bouncy.remainingBounces;
      legacy.bouncesRemaining = bouncy.remainingBounces;
    }

    const cooldowns = entity.components.cooldowns;
    if (cooldowns) {
      if (cooldowns.attack != null) legacy.attackCooldown = cooldowns.attack;
      if (cooldowns.spell != null) legacy.spellCooldown = cooldowns.spell;
      if (cooldowns.shield != null) legacy.shieldRemaining = cooldowns.shield;
      if (cooldowns.breath != null) legacy.breathCooldown = cooldowns.breath;
      if (cooldowns.windup != null) legacy.actionWindupRemaining = cooldowns.windup;
    }

    const casting = entity.components.casting;
    if (casting) {
      legacy.isCasting = casting.isCasting;
      legacy.castingSpell = casting.spell;
      legacy.castingTargetId = casting.targetId;
      legacy.castingAimDirection = casting.aimDirection;
      legacy.castingBoardPoint = casting.boardPoint;
      legacy.castingRemaining = casting.remaining;
    }
  }
}

export function legacyObjectToEntity(sourceType, legacyObject) {
  return ecsWorld.get(entityIdForLegacy(sourceType, legacyObject));
}

export function entityToLegacyObject(entityOrId) {
  const entity = typeof entityOrId === "string" ? ecsWorld.get(entityOrId) : entityOrId;
  return entity?.components?.legacyRef?.ref ?? null;
}

export function getLegacyObjectsFromEntities(entities) {
  return entities.map(entityToLegacyObject).filter(Boolean);
}

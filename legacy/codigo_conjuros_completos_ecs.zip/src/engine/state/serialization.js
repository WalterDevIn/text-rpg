export function serializeGameState(gameState) {
  return JSON.stringify(gameState);
}

export function deserializeGameState(serialized) {
  return JSON.parse(serialized);
}

import { gameState } from "./gameState.js";
import { serializeGameState, deserializeGameState } from "./serialization.js";

export function saveGameState(storage = localStorage, key = "rogue-canvas-save") {
  storage.setItem(key, serializeGameState(gameState));
}

export function loadGameState(storage = localStorage, key = "rogue-canvas-save") {
  const raw = storage.getItem(key);
  return raw ? deserializeGameState(raw) : null;
}

export { spawnChromaticOrbShot } from "../projectileSystem.js";

export { spawnArrowShot, spawnArrowShotAtPoint } from "../projectileSystem.js";

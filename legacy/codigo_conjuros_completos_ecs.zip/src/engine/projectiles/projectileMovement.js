export { normalizeVector, getDirection, getDistance } from "../world/collision.js";

export * from "../../content/spells/spellCasting.js";

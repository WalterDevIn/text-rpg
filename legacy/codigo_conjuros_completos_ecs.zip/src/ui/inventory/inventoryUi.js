export * from "../../content/items/inventory.js";

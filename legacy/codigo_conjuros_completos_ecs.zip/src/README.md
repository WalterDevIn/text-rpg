# src

Arquitectura dura del juego. No existe carpeta `js/` ni `src/legacy/`.

- `app/`: arranque, bootstrap y game loop.
- `engine/`: estado, ECS, sistemas, mundo, reglas y eventos.
- `content/`: definiciones y lógica de contenido.
- `ui/`: módulos de interfaz.
- `render/`: canvas, cámara y renderizado.
- `utils/`: utilidades pequeñas.

Frontera híbrida: ECS para simulación viva; módulos normales para contenido, UI, render, input físico, guardado y generación.

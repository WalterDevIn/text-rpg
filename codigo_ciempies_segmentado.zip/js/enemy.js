import {
  TILE_SIZE,
  ENEMY_SPEED,
  ENEMY_FLEE_SPEED,
  ENEMY_DETECTION_RANGE_PIXELS,
  ENEMY_LOW_HP_PERCENT,
  ENEMY_ATTACK_COOLDOWN,
  ENEMY_ATTACK_DAMAGE,
  ENEMY_ACTION_CAST_TIME,
  ENEMY_SPELL_COOLDOWN,
  ENEMY_MAGIC_MISSILE_RANGE_PIXELS,
  ENEMY_SEPARATION_RANGE_PIXELS,
  ENEMY_SEPARATION_STRENGTH,
  ENEMY_PATH_RECALC_INTERVAL,
  ENEMY_PATH_NODE_REACHED_DISTANCE,
  ENEMY_LOST_TARGET_DISTANCE,
  ENEMY_CASTER_MIN_DISTANCE_PIXELS,
  ENEMY_CASTER_PREFERRED_DISTANCE_PIXELS,
  DRAGON_BOSS_ROOM_MIN_FLOOR_TILES,
  DRAGON_BOSS_SPAWN_CHANCE,
  CENTIPEDE_SPAWN_CHANCE,
  DRAGON_BOSS_SIZE_TILES,
  DRAGON_BOSS_RADIUS,
  DRAGON_BOSS_HP,
  DRAGON_BOSS_MELEE_DAMAGE,
  DRAGON_BOSS_BREATH_DAMAGE_DICE,
  DRAGON_BOSS_BREATH_DAMAGE_DIE,
  DRAGON_BOSS_BREATH_RANGE_PIXELS,
  DRAGON_BOSS_BREATH_CONE_ANGLE_RADIANS,
  DRAGON_BOSS_BREATH_COOLDOWN,
  CENTIPEDE_SEGMENT_COUNT,
  CENTIPEDE_SEGMENT_SPACING,
  CENTIPEDE_TURN_SPEED,
  CENTIPEDE_SPEED,
  CENTIPEDE_ATTACK_DAMAGE,
} from "./constants.js";

import { EnemyState, gameState } from "./state.js";
import { player } from "./player.js";
import { getDistance, getDirection, moveEntityWithCollision, normalizeVector } from "./physics.js";
import { isInAttackRange } from "./combat.js";
import { spawnDragonBreathFlames, spawnMagicMissileVolley } from "./projectiles.js";
import { isEntityVisibleToPlayer, isStaticWallAt } from "./map.js";
import { findPath, hasLineOfSight, worldToTile } from "./pathfinding.js";
import { isPointInCone } from "./spellGeometry.js";
import { rollDie } from "./dice.js";

export const enemies = [];

let nextEnemyId = 1;
let nextCentipedeChainId = 1;
let hasRequiredRareEnemySpawned = false;

const enemyTemplates = [
  {
    name: "Trasgo",
    portraitKey: "trasgo",
    portraitName: "trasgo",
    char: "g",
    color: "#ff4444",
    hp: 10,
    maxHp: 10,
    canCastMagicMissile: false,
    weight: 42,
  },
  {
    name: "Rata gigante",
    portraitKey: "rata_gigante",
    portraitName: "rata_gigante",
    char: "r",
    color: "#bb9966",
    hp: 7,
    maxHp: 7,
    canCastMagicMissile: false,
    weight: 24,
  },
  {
    name: "Esqueleto",
    portraitKey: "esqueleto",
    portraitName: "esqueleto",
    char: "s",
    color: "#dddddd",
    hp: 12,
    maxHp: 12,
    canCastMagicMissile: false,
    weight: 22,
  },
  {
    name: "Ciempiés",
    portraitKey: "ciempies",
    portraitName: "ciempies",
    char: "c",
    color: "#79cc55",
    hp: 9,
    maxHp: 9,
    canCastMagicMissile: false,
    kind: "centipede",
    weight: 3,
  },
  {
    name: "Dragón jefe",
    portraitKey: "dragon_jefe",
    portraitName: "dragon_jefe",
    char: "D",
    color: "#ff5533",
    hp: DRAGON_BOSS_HP,
    maxHp: DRAGON_BOSS_HP,
    canCastMagicMissile: false,
    kind: "dragon_boss",
    weight: 1,
  },
  {
    name: "Acólito hostil",
    portraitKey: "acolito_hostil",
    portraitName: "acolito_hostil",
    char: "m",
    color: "#cc66ff",
    hp: 8,
    maxHp: 8,
    canCastMagicMissile: true,
    weight: 12,
  },
];

export function spawnEnemiesForGeneratedRoom(room, difficulty = "easy") {
  if (!room || difficulty === "none" || difficulty === "merchant") {
    return 0;
  }

  const mandatoryRare = trySpawnMandatoryRareEnemy(room, difficulty);

  if (mandatoryRare > 0) {
    return mandatoryRare;
  }

  if (shouldSpawnDragonBoss(room, difficulty)) {
    const point = getRandomPointInsideRoom(room, { marginTiles: 2, minDistanceTiles: 3 });

    if (point) {
      enemies.push(createEnemyFromTemplate(getTemplateByKind("dragon_boss"), point.x, point.y));
      hasRequiredRareEnemySpawned = true;
      return 1;
    }
  }

  if (shouldSpawnCentipede(difficulty)) {
    const point = getRandomPointInsideRoom(room, { marginTiles: 1, minDistanceTiles: 3 });

    if (point) {
      spawnCentipede(point.x, point.y);
      hasRequiredRareEnemySpawned = true;
      return 1;
    }
  }

  const count = getEnemyCountForDifficulty(difficulty);
  let spawned = 0;

  for (let i = 0; i < count; i++) {
    const point = getRandomPointInsideRoom(room);

    if (!point) {
      continue;
    }

    const enemy = createRandomEnemy(point.x, point.y);
    enemies.push(enemy);
    spawned++;
  }

  return spawned;
}

export function resetRareEnemyRequirement() {
  hasRequiredRareEnemySpawned = false;
}

function trySpawnMandatoryRareEnemy(room, difficulty) {
  if (hasRequiredRareEnemySpawned || difficulty === "none") {
    return 0;
  }

  const floorTiles = Math.max(0, room.width - 2) * Math.max(0, room.height - 2);
  const canFitDragon = floorTiles >= DRAGON_BOSS_ROOM_MIN_FLOOR_TILES;
  const preferDragon = difficulty === "boss" || difficulty === "deadly" || Math.random() < 0.45;

  if (canFitDragon && preferDragon) {
    const dragonPoint = getRandomPointInsideRoom(room, { marginTiles: 2, minDistanceTiles: 3 });

    if (dragonPoint) {
      enemies.push(createEnemyFromTemplate(getTemplateByKind("dragon_boss"), dragonPoint.x, dragonPoint.y));
      hasRequiredRareEnemySpawned = true;
      return 1;
    }
  }

  const centipedePoint = getRandomPointInsideRoom(room, { marginTiles: 1, minDistanceTiles: 3 });

  if (centipedePoint) {
    spawnCentipede(centipedePoint.x, centipedePoint.y);
    hasRequiredRareEnemySpawned = true;
    return 1;
  }

  if (canFitDragon) {
    const dragonPoint = getRandomPointInsideRoom(room, { marginTiles: 1, minDistanceTiles: 2 });

    if (dragonPoint) {
      enemies.push(createEnemyFromTemplate(getTemplateByKind("dragon_boss"), dragonPoint.x, dragonPoint.y));
      hasRequiredRareEnemySpawned = true;
      return 1;
    }
  }

  return 0;
}

export function updateEnemies(deltaTime) {
  for (const enemy of enemies) {
    if (enemy.hp <= 0 && !enemy.deathProcessed) {
      killEnemy(enemy);
    }

    updateEnemyCooldowns(enemy, deltaTime);
    updateEnemy(enemy, deltaTime);
  }
}

function createRandomEnemy(x, y) {
  const template = weightedRandom(enemyTemplates.filter((item) => !item.kind));
  return createEnemyFromTemplate(template, x, y);
}

function createEnemyFromTemplate(template, x, y) {
  const id = nextEnemyId++;
  const kind = template.kind ?? "normal";
  const radius = kind === "dragon_boss" ? DRAGON_BOSS_RADIUS : TILE_SIZE * 0.35;
  const drawSize = kind === "dragon_boss" ? TILE_SIZE * DRAGON_BOSS_SIZE_TILES : undefined;
  const angle = Math.random() * Math.PI * 2;

  const enemy = {
    id,
    kind,
    name: `${template.name} ${id}`,
    portraitKey: template.portraitKey,
    portraitName: template.portraitName,
    x,
    y,
    radius,
    drawSize,
    char: template.char,
    baseColor: template.color,
    color: template.color,
    hp: template.hp,
    maxHp: template.maxHp,
    attackCooldown: Math.random() * 0.75,
    spellCooldown: template.canCastMagicMissile ? 2 + Math.random() * 2 : 0,
    breathCooldown: kind === "dragon_boss" ? 2 + Math.random() * 2 : 0,
    actionWindupType: null,
    actionWindupRemaining: 0,
    canCastMagicMissile: template.canCastMagicMissile,
    hasSeenPlayer: false,
    lastKnownPlayerPosition: null,
    path: [],
    pathTargetTileKey: null,
    pathRecalcRemaining: 0,
    state: EnemyState.IDLE,
    angle,
  };

  return enemy;
}

function getEnemyCountForDifficulty(difficulty) {
  if (difficulty === "easy") return randomInt(1, 2);
  if (difficulty === "medium") return randomInt(2, 3);
  if (difficulty === "hard") return randomInt(3, 4);
  if (difficulty === "deadly") return randomInt(4, 5);
  if (difficulty === "boss") return randomInt(3, 5);
  return randomInt(1, 2);
}

function getRandomPointInsideRoom(room, options = {}) {
  const marginTiles = options.marginTiles ?? 1;
  const minDistanceTiles = options.minDistanceTiles ?? 2;
  const minRow = room.row + marginTiles;
  const maxRow = room.row + room.height - 1 - marginTiles;
  const minCol = room.col + marginTiles;
  const maxCol = room.col + room.width - 1 - marginTiles;

  if (minRow > maxRow || minCol > maxCol) {
    return null;
  }

  for (let attempt = 0; attempt < 30; attempt++) {
    const row = randomInt(minRow, maxRow);
    const col = randomInt(minCol, maxCol);
    const x = col * TILE_SIZE + TILE_SIZE / 2;
    const y = row * TILE_SIZE + TILE_SIZE / 2;

    const tooCloseToPlayer = Math.hypot(x - player.x, y - player.y) < TILE_SIZE * minDistanceTiles;
    const blockedByWall = isStaticWallAt(row, col);

    if (!tooCloseToPlayer && !blockedByWall) {
      return { x, y };
    }
  }

  for (let row = minRow; row <= maxRow; row++) {
    for (let col = minCol; col <= maxCol; col++) {
      if (!isStaticWallAt(row, col)) {
        return {
          x: col * TILE_SIZE + TILE_SIZE / 2,
          y: row * TILE_SIZE + TILE_SIZE / 2,
        };
      }
    }
  }

  return null;
}

function updateEnemyCooldowns(enemy, deltaTime) {
  enemy.attackCooldown = Math.max(0, enemy.attackCooldown - deltaTime);
  enemy.spellCooldown = Math.max(0, enemy.spellCooldown - deltaTime);
  enemy.breathCooldown = Math.max(0, (enemy.breathCooldown ?? 0) - deltaTime);
  enemy.actionWindupRemaining = Math.max(0, (enemy.actionWindupRemaining ?? 0) - deltaTime);
  enemy.pathRecalcRemaining = Math.max(0, (enemy.pathRecalcRemaining ?? 0) - deltaTime);
}

function updateEnemy(enemy, deltaTime) {
  if (enemy.state === EnemyState.DEAD) {
    return;
  }

  if (enemy.hp <= 0) {
    killEnemy(enemy);
    return;
  }

  const canSeePlayerNow = canEnemySeePlayer(enemy);
  updateEnemyMemory(enemy, canSeePlayerNow);

  if (updateEnemyActionWindup(enemy, canSeePlayerNow)) {
    return;
  }

  if (enemy.kind === "centipede_part") {
    updateCentipedePart(enemy, canSeePlayerNow, deltaTime);
    return;
  }

  updateEnemyState(enemy, canSeePlayerNow);

  if (enemy.state === EnemyState.IDLE) {
    driftAwayFromCrowd(enemy, deltaTime);
    return;
  }

  if (enemy.state === EnemyState.CHASE) {
    moveEnemyUsingPath(enemy, getCurrentTargetPosition(enemy), ENEMY_SPEED, deltaTime);
    return;
  }

  if (enemy.state === EnemyState.ATTACK) {
    enemyAttack(enemy);
    return;
  }

  if (enemy.state === EnemyState.CAST) {
    enemyCastMagicMissile(enemy);
    return;
  }

  if (enemy.state === EnemyState.FLEE) {
    moveEnemyAwayFromPoint(enemy, player, ENEMY_FLEE_SPEED, deltaTime);
  }
}

function updateEnemyMemory(enemy, canSeePlayerNow) {
  if (!canSeePlayerNow) {
    return;
  }

  enemy.hasSeenPlayer = true;
  enemy.lastKnownPlayerPosition = { x: player.x, y: player.y };
}

function updateEnemyState(enemy, canSeePlayerNow) {
  const distance = getDistance(enemy, player);
  const lowHp = enemy.hp / enemy.maxHp <= ENEMY_LOW_HP_PERCENT;

  if (!enemy.hasSeenPlayer && !canSeePlayerNow) {
    enemy.state = EnemyState.IDLE;
    enemy.color = enemy.canCastMagicMissile ? "#664488" : "#884444";
    return;
  }

  if (lowHp) {
    enemy.state = EnemyState.FLEE;
    enemy.color = "#ffaa00";
    return;
  }

  if (enemy.kind === "dragon_boss") {
    updateDragonState(enemy, canSeePlayerNow, distance);
    return;
  }

  if (enemy.canCastMagicMissile) {
    updateCasterState(enemy, canSeePlayerNow, distance);
    return;
  }

  if (canSeePlayerNow && isEnemyMeleeInRange(enemy) && !isOverlappingAnotherEnemy(enemy)) {
    enemy.state = EnemyState.ATTACK;
    enemy.color = "#ff0000";
    return;
  }

  if (enemy.lastKnownPlayerPosition) {
    enemy.state = EnemyState.CHASE;
    enemy.color = "#ff4444";

    if (!canSeePlayerNow && getDistance(enemy, enemy.lastKnownPlayerPosition) <= ENEMY_LOST_TARGET_DISTANCE) {
      forgetPlayer(enemy);
    }
    return;
  }

  enemy.state = EnemyState.IDLE;
  enemy.color = enemy.canCastMagicMissile ? "#664488" : "#884444";
}

function updateCasterState(enemy, canSeePlayerNow, distance) {
  if (canSeePlayerNow && distance < ENEMY_CASTER_MIN_DISTANCE_PIXELS) {
    enemy.state = EnemyState.FLEE;
    enemy.color = "#dd88ff";
    return;
  }

  if (canEnemyCastMagicMissile(enemy, distance, canSeePlayerNow)) {
    enemy.state = EnemyState.CAST;
    enemy.color = "#cc66ff";
    return;
  }

  if (canSeePlayerNow && distance < ENEMY_CASTER_PREFERRED_DISTANCE_PIXELS) {
    enemy.state = EnemyState.FLEE;
    enemy.color = "#dd88ff";
    return;
  }

  if (enemy.lastKnownPlayerPosition) {
    enemy.state = EnemyState.CHASE;
    enemy.color = "#cc66ff";

    if (!canSeePlayerNow && getDistance(enemy, enemy.lastKnownPlayerPosition) <= ENEMY_LOST_TARGET_DISTANCE) {
      forgetPlayer(enemy);
    }
    return;
  }

  enemy.state = EnemyState.IDLE;
  enemy.color = "#664488";
}


function updateDragonState(enemy, canSeePlayerNow, distance) {
  if (canDragonUseBreath(enemy, distance, canSeePlayerNow)) {
    enemy.state = EnemyState.CAST;
    enemy.color = "#ff3300";
    startEnemyActionWindup(enemy, "dragon_breath");
    return;
  }

  if (canSeePlayerNow && isEnemyMeleeInRange(enemy) && !isOverlappingAnotherEnemy(enemy)) {
    enemy.state = EnemyState.ATTACK;
    enemy.color = "#ff0000";
    return;
  }

  if (enemy.lastKnownPlayerPosition) {
    enemy.state = EnemyState.CHASE;
    enemy.color = "#ff5533";

    if (!canSeePlayerNow && getDistance(enemy, enemy.lastKnownPlayerPosition) <= ENEMY_LOST_TARGET_DISTANCE) {
      forgetPlayer(enemy);
    }
    return;
  }

  enemy.state = EnemyState.IDLE;
  enemy.color = "#884433";
}

function canDragonUseBreath(enemy, distanceToPlayer, canSeePlayerNow) {
  return (
    enemy.kind === "dragon_boss" &&
    canSeePlayerNow &&
    (enemy.breathCooldown ?? 0) <= 0 &&
    distanceToPlayer <= DRAGON_BOSS_BREATH_RANGE_PIXELS &&
    player.hp > 0
  );
}

function canEnemySeePlayer(enemy) {
  if (enemy.kind === "centipede_part" && !enemy.isCentipedeHead) {
    return false;
  }

  if (player.hp <= 0) {
    return false;
  }

  const sightRange = enemy.canCastMagicMissile
    ? ENEMY_MAGIC_MISSILE_RANGE_PIXELS
    : ENEMY_DETECTION_RANGE_PIXELS;

  if (getDistance(enemy, player) > sightRange) {
    return false;
  }

  if (!isEntityVisibleToPlayer(enemy, player)) {
    return false;
  }

  return hasLineOfSight(enemy, player);
}

function canEnemyCastMagicMissile(enemy, distanceToPlayer, canSeePlayerNow) {
  return (
    canSeePlayerNow &&
    enemy.canCastMagicMissile &&
    enemy.spellCooldown <= 0 &&
    distanceToPlayer <= ENEMY_MAGIC_MISSILE_RANGE_PIXELS &&
    player.hp > 0
  );
}

function getCurrentTargetPosition(enemy) {
  return enemy.lastKnownPlayerPosition ?? { x: player.x, y: player.y };
}

function moveEnemyUsingPath(enemy, target, speed, deltaTime) {
  if (!target) {
    driftAwayFromCrowd(enemy, deltaTime);
    return;
  }

  const pathTarget = getNextPathPoint(enemy, target);
  const baseDirection = pathTarget ? getDirection(enemy, pathTarget) : getDirection(enemy, target);
  const direction = blendWithSeparation(enemy, baseDirection);

  moveEnemyByDirection(enemy, direction, speed, deltaTime);
}

function getNextPathPoint(enemy, target) {
  const targetTile = worldToTile(target);
  const targetTileKey = `${targetTile.row},${targetTile.col}`;

  if (
    !enemy.path ||
    enemy.path.length === 0 ||
    enemy.pathTargetTileKey !== targetTileKey ||
    enemy.pathRecalcRemaining <= 0
  ) {
    enemy.path = findPath(enemy, target);
    enemy.pathTargetTileKey = targetTileKey;
    enemy.pathRecalcRemaining = ENEMY_PATH_RECALC_INTERVAL;
  }

  while (enemy.path.length > 0 && getDistance(enemy, enemy.path[0]) <= ENEMY_PATH_NODE_REACHED_DISTANCE) {
    enemy.path.shift();
  }

  return enemy.path[0] ?? null;
}

function moveEnemyAwayFromPoint(enemy, point, speed, deltaTime) {
  const baseDirection = getDirection(point, enemy);
  const direction = blendWithSeparation(enemy, baseDirection);
  moveEnemyByDirection(enemy, direction, speed, deltaTime);
}

function driftAwayFromCrowd(enemy, deltaTime) {
  const separation = getSeparationVector(enemy);

  if (separation.x === 0 && separation.y === 0) {
    return;
  }

  moveEnemyByDirection(enemy, separation, ENEMY_SPEED * 0.45, deltaTime);
}

function moveEnemyByDirection(enemy, direction, speed, deltaTime) {
  const normalized = normalizeVector(direction.x, direction.y);

  if (normalized.x === 0 && normalized.y === 0) {
    return;
  }

  const nextX = enemy.x + normalized.x * speed * deltaTime;
  const nextY = enemy.y + normalized.y * speed * deltaTime;

  // Los enemigos sólo colisionan con el mapa. Entre ellos pueden sobrepasarse,
  // pero la separación hace que no elijan amontonarse salvo que sea necesario.
  if (enemy.ignoreWallCollision) {
    enemy.x = nextX;
    enemy.y = nextY;
    return;
  }

  moveEntityWithCollision(enemy, nextX, nextY);
}

function blendWithSeparation(enemy, baseDirection) {
  const separation = getSeparationVector(enemy);

  return normalizeVector(
    baseDirection.x + separation.x * ENEMY_SEPARATION_STRENGTH,
    baseDirection.y + separation.y * ENEMY_SEPARATION_STRENGTH
  );
}

function getSeparationVector(enemy) {
  let x = 0;
  let y = 0;

  for (const other of enemies) {
    if (other === enemy || other.state === EnemyState.DEAD || other.hp <= 0) {
      continue;
    }

    if (enemy.kind === "centipede_part" && other.kind === "centipede_part" && enemy.centipedeId === other.centipedeId) {
      continue;
    }

    const distance = getDistance(enemy, other);

    if (distance <= 0 || distance > ENEMY_SEPARATION_RANGE_PIXELS) {
      continue;
    }

    const pressure = (ENEMY_SEPARATION_RANGE_PIXELS - distance) / ENEMY_SEPARATION_RANGE_PIXELS;
    x += ((enemy.x - other.x) / distance) * pressure;
    y += ((enemy.y - other.y) / distance) * pressure;
  }

  return normalizeVector(x, y);
}


function spawnCentipede(x, y) {
  const template = getTemplateByKind("centipede");
  const angle = Math.random() * Math.PI * 2;
  const centipedeId = nextCentipedeChainId++;
  const parts = [];

  for (let i = 0; i < CENTIPEDE_SEGMENT_COUNT; i++) {
    parts.push(createCentipedePart({
      template,
      centipedeId,
      segmentIndex: i,
      x: x - Math.cos(angle) * CENTIPEDE_SEGMENT_SPACING * i,
      y: y - Math.sin(angle) * CENTIPEDE_SEGMENT_SPACING * i,
      angle,
    }));
  }

  enemies.push(...parts);
  return parts;
}

function createCentipedePart({ template, centipedeId, segmentIndex, x, y, angle }) {
  const id = nextEnemyId++;
  const isHead = segmentIndex === 0;

  return {
    id,
    kind: "centipede_part",
    centipedeId,
    segmentIndex,
    isCentipedeHead: isHead,
    name: isHead ? `Ciempiés ${centipedeId} cabeza` : `Ciempiés ${centipedeId} segmento ${segmentIndex + 1}`,
    portraitKey: template.portraitKey,
    portraitName: template.portraitName,
    x,
    y,
    radius: TILE_SIZE * 0.32,
    drawSize: isHead ? TILE_SIZE * 0.9 : TILE_SIZE * 0.72,
    char: isHead ? template.char : "o",
    baseColor: template.color,
    color: isHead ? template.color : "#5fa845",
    hp: template.hp,
    maxHp: template.maxHp,
    attackCooldown: isHead ? Math.random() * 0.75 : 0,
    spellCooldown: 0,
    breathCooldown: 0,
    actionWindupType: null,
    actionWindupRemaining: 0,
    canCastMagicMissile: false,
    hasSeenPlayer: false,
    lastKnownPlayerPosition: null,
    path: [],
    pathTargetTileKey: null,
    pathRecalcRemaining: 0,
    state: EnemyState.IDLE,
    angle,
    ignoreWallCollision: true,
  };
}

function updateCentipedePart(enemy, canSeePlayerNow, deltaTime) {
  enemy.ignoreWallCollision = true;

  if (enemy.isCentipedeHead) {
    updateCentipedeHead(enemy, canSeePlayerNow, deltaTime);
    return;
  }

  updateCentipedeBodyPart(enemy, deltaTime);
}

function updateCentipedeHead(enemy, canSeePlayerNow, deltaTime) {
  if (!enemy.hasSeenPlayer && !canSeePlayerNow) {
    enemy.state = EnemyState.IDLE;
    enemy.color = "#446633";
    return;
  }

  if (canSeePlayerNow && isEnemyMeleeInRange(enemy) && enemy.attackCooldown <= 0) {
    enemy.state = EnemyState.ATTACK;
    enemy.color = "#99ee66";
    startEnemyActionWindup(enemy, "attack");
    return;
  }

  const target = enemy.lastKnownPlayerPosition ?? player;
  turnCentipedeToward(enemy, target, deltaTime);
  enemy.x += Math.cos(enemy.angle) * CENTIPEDE_SPEED * deltaTime;
  enemy.y += Math.sin(enemy.angle) * CENTIPEDE_SPEED * deltaTime;
  enemy.state = EnemyState.CHASE;
  enemy.color = "#79cc55";

  if (!canSeePlayerNow && enemy.lastKnownPlayerPosition && getDistance(enemy, enemy.lastKnownPlayerPosition) <= ENEMY_LOST_TARGET_DISTANCE) {
    forgetPlayer(enemy);
  }
}

function updateCentipedeBodyPart(enemy, deltaTime) {
  const previous = getPreviousCentipedePart(enemy);

  if (!previous) {
    promoteCentipedePartToHead(enemy);
    updateCentipedeHead(enemy, canEnemySeePlayer(enemy), deltaTime);
    return;
  }

  enemy.state = previous.state;
  enemy.hasSeenPlayer = previous.hasSeenPlayer;
  enemy.lastKnownPlayerPosition = previous.lastKnownPlayerPosition ? { ...previous.lastKnownPlayerPosition } : null;
  enemy.color = "#5fa845";

  const dx = previous.x - enemy.x;
  const dy = previous.y - enemy.y;
  const distance = Math.hypot(dx, dy);

  if (distance <= 0) {
    return;
  }

  const desiredDistance = CENTIPEDE_SEGMENT_SPACING;

  if (distance > desiredDistance) {
    const moveDistance = Math.min(distance - desiredDistance, CENTIPEDE_SPEED * 1.25 * deltaTime);
    enemy.x += (dx / distance) * moveDistance;
    enemy.y += (dy / distance) * moveDistance;
  }

  enemy.angle = Math.atan2(dy, dx);
}

function getPreviousCentipedePart(enemy) {
  return enemies.find((candidate) => {
    return (
      candidate.kind === "centipede_part" &&
      candidate.centipedeId === enemy.centipedeId &&
      candidate.segmentIndex === enemy.segmentIndex - 1 &&
      candidate.hp > 0 &&
      candidate.state !== EnemyState.DEAD
    );
  }) ?? null;
}

function promoteCentipedePartToHead(enemy) {
  enemy.isCentipedeHead = true;
  enemy.segmentIndex = 0;
  enemy.char = "c";
  enemy.drawSize = TILE_SIZE * 0.9;
  enemy.name = `Ciempiés ${enemy.centipedeId} cabeza`;
  enemy.attackCooldown = Math.max(enemy.attackCooldown ?? 0, 0.25);
  enemy.color = "#79cc55";
}

function splitCentipedeOnDeath(deadPart) {
  if (deadPart.kind !== "centipede_part") {
    return;
  }

  const livingParts = enemies
    .filter((part) => {
      return (
        part.kind === "centipede_part" &&
        part.centipedeId === deadPart.centipedeId &&
        part !== deadPart &&
        part.hp > 0 &&
        part.state !== EnemyState.DEAD
      );
    })
    .sort((a, b) => a.segmentIndex - b.segmentIndex);

  const frontParts = livingParts.filter((part) => part.segmentIndex < deadPart.segmentIndex);
  const rearParts = livingParts.filter((part) => part.segmentIndex > deadPart.segmentIndex);

  reindexCentipedeChain(frontParts, deadPart.centipedeId);

  if (rearParts.length > 0) {
    reindexCentipedeChain(rearParts, nextCentipedeChainId++);
  }
}

function reindexCentipedeChain(parts, centipedeId) {
  parts
    .sort((a, b) => a.segmentIndex - b.segmentIndex)
    .forEach((part, index) => {
      part.centipedeId = centipedeId;
      part.segmentIndex = index;
      part.isCentipedeHead = index === 0;
      part.char = index === 0 ? "c" : "o";
      part.drawSize = index === 0 ? TILE_SIZE * 0.9 : TILE_SIZE * 0.72;
      part.name = index === 0 ? `Ciempiés ${centipedeId} cabeza` : `Ciempiés ${centipedeId} segmento ${index + 1}`;
      part.color = index === 0 ? "#79cc55" : "#5fa845";

      if (index === 0) {
        part.attackCooldown = Math.max(part.attackCooldown ?? 0, 0.35);
        part.actionWindupType = null;
        part.actionWindupRemaining = 0;
      } else {
        part.actionWindupType = null;
        part.actionWindupRemaining = 0;
      }
    });
}

function turnCentipedeToward(enemy, target, deltaTime) {
  const desiredAngle = Math.atan2(target.y - enemy.y, target.x - enemy.x);
  const angleDelta = normalizeAngle(desiredAngle - enemy.angle);
  const applied = Math.max(-CENTIPEDE_TURN_SPEED * deltaTime, Math.min(CENTIPEDE_TURN_SPEED * deltaTime, angleDelta));
  enemy.angle += applied;
}

function normalizeAngle(angle) {
  while (angle > Math.PI) angle -= Math.PI * 2;
  while (angle < -Math.PI) angle += Math.PI * 2;
  return angle;
}


function isEnemyMeleeInRange(enemy) {
  if (enemy.kind === "dragon_boss") {
    return getDistance(enemy, player) <= enemy.radius + player.radius + TILE_SIZE * 0.75;
  }

  if (enemy.kind === "centipede_part") {
    return enemy.isCentipedeHead && getDistance(enemy, player) <= enemy.radius + player.radius + TILE_SIZE * 0.45;
  }

  return isInAttackRange(enemy, player);
}

function enemyAttack(enemy) {
  if (enemy.attackCooldown > 0) {
    return;
  }

  startEnemyActionWindup(enemy, "attack");
}

function resolveEnemyAttack(enemy) {
  if (!isEnemyMeleeInRange(enemy)) {
    return;
  }

  if (!canEnemySeePlayer(enemy)) {
    return;
  }

  if (isOverlappingAnotherEnemy(enemy)) {
    gameState.message = `${enemy.name} intenta golpearte, pero está cruzándose con otro enemigo.`;
    return;
  }

  const damage = getEnemyMeleeDamage(enemy);
  player.hp = Math.max(0, player.hp - damage);
  enemy.attackCooldown = ENEMY_ATTACK_COOLDOWN;

  if (player.hp <= 0) {
    gameState.message = `${enemy.name} te golpea por ${damage} de daño. Has muerto.`;
    return;
  }

  gameState.message = `${enemy.name} te golpea por ${damage} de daño.`;
}

function enemyCastMagicMissile(enemy) {
  if (enemy.spellCooldown > 0 || player.hp <= 0) {
    return;
  }

  startEnemyActionWindup(enemy, "magic_missile");
}

function resolveEnemyMagicMissile(enemy) {
  if (!canEnemySeePlayer(enemy)) {
    return;
  }

  const spawned = spawnMagicMissileVolley(enemy, player);

  if (!spawned) {
    return;
  }

  enemy.spellCooldown = ENEMY_SPELL_COOLDOWN;
  gameState.message = `${enemy.name} conjura Misil mágico contra ti.`;
}



function resolveDragonBreath(enemy) {
  if (!canEnemySeePlayer(enemy)) {
    return;
  }

  const direction = getDirection(enemy, player);
  const damageRolls = rollMany(DRAGON_BOSS_BREATH_DAMAGE_DICE, DRAGON_BOSS_BREATH_DAMAGE_DIE);
  const damage = damageRolls.reduce((sum, roll) => sum + roll, 0);

  spawnDragonBreathFlames(enemy, direction);
  enemy.breathCooldown = DRAGON_BOSS_BREATH_COOLDOWN;

  if (isPointInCone(enemy, direction, player, DRAGON_BOSS_BREATH_RANGE_PIXELS, DRAGON_BOSS_BREATH_CONE_ANGLE_RADIANS)) {
    player.hp = Math.max(0, player.hp - damage);
    gameState.message = `${enemy.name} exhala una llamarada mayor. Recibes ${damage} de daño (${damageRolls.join(" + ")}).`;

    if (player.hp <= 0) {
      gameState.message += " Has muerto.";
    }
    return;
  }

  gameState.message = `${enemy.name} exhala una llamarada mayor, pero quedas fuera del cono.`;
}

function getEnemyMeleeDamage(enemy) {
  if (enemy.kind === "dragon_boss") {
    return DRAGON_BOSS_MELEE_DAMAGE;
  }

  if (enemy.kind === "centipede_part") {
    return CENTIPEDE_ATTACK_DAMAGE;
  }

  return ENEMY_ATTACK_DAMAGE;
}

function rollMany(count, die) {
  const rolls = [];

  for (let i = 0; i < count; i++) {
    rolls.push(rollDie(die));
  }

  return rolls;
}

function startEnemyActionWindup(enemy, type) {
  if (enemy.actionWindupType) {
    return;
  }

  enemy.actionWindupType = type;
  enemy.actionWindupRemaining = ENEMY_ACTION_CAST_TIME;
  enemy.color = type === "magic_missile" ? "#ff99ff" : "#ff7777";

  if (type === "magic_missile") {
    gameState.message = `${enemy.name} empieza a conjurar Misil mágico.`;
  } else if (type === "dragon_breath") {
    gameState.message = `${enemy.name} toma aire y prepara una llamarada mayor.`;
  } else {
    gameState.message = `${enemy.name} prepara un ataque.`;
  }
}

function updateEnemyActionWindup(enemy, canSeePlayerNow) {
  if (!enemy.actionWindupType) {
    return false;
  }

  const type = enemy.actionWindupType;

  if (enemy.actionWindupRemaining > 0) {
    enemy.state = type === "magic_missile" || type === "dragon_breath" ? EnemyState.CAST : EnemyState.ATTACK;
    return true;
  }

  enemy.actionWindupType = null;

  if (type === "magic_missile") {
    if (canSeePlayerNow && enemy.spellCooldown <= 0) {
      resolveEnemyMagicMissile(enemy);
    }
    return true;
  }

  if (type === "dragon_breath") {
    if (canSeePlayerNow && (enemy.breathCooldown ?? 0) <= 0) {
      resolveDragonBreath(enemy);
    }
    return true;
  }

  if (canSeePlayerNow && enemy.attackCooldown <= 0) {
    resolveEnemyAttack(enemy);
  }

  return true;
}

function isOverlappingAnotherEnemy(enemy) {
  return enemies.some((other) => {
    if (other === enemy || other.state === EnemyState.DEAD || other.hp <= 0) {
      return false;
    }

    if (enemy.kind === "centipede_part" && other.kind === "centipede_part" && enemy.centipedeId === other.centipedeId) {
      return false;
    }

    return getDistance(enemy, other) < (enemy.radius + other.radius) * 0.9;
  });
}

function forgetPlayer(enemy) {
  enemy.hasSeenPlayer = false;
  enemy.lastKnownPlayerPosition = null;
  enemy.path = [];
  enemy.pathTargetTileKey = null;
}

export function killEnemy(enemy) {
  if (!enemy || enemy.deathProcessed) {
    return;
  }

  enemy.deathProcessed = true;
  enemy.hp = 0;
  enemy.state = EnemyState.DEAD;
  enemy.char = "%";
  enemy.color = "#777777";
  enemy.actionWindupType = null;
  enemy.actionWindupRemaining = 0;

  if (enemy.kind === "centipede_part") {
    splitCentipedeOnDeath(enemy);
  }
}


function shouldSpawnDragonBoss(room, difficulty) {
  const floorTiles = Math.max(0, room.width - 2) * Math.max(0, room.height - 2);
  const eligibleDifficulty = difficulty === "boss" || difficulty === "deadly";
  return eligibleDifficulty && floorTiles >= DRAGON_BOSS_ROOM_MIN_FLOOR_TILES && Math.random() < DRAGON_BOSS_SPAWN_CHANCE;
}

function shouldSpawnCentipede(difficulty) {
  const eligibleDifficulty = difficulty === "medium" || difficulty === "hard" || difficulty === "deadly" || difficulty === "boss";
  return eligibleDifficulty && Math.random() < CENTIPEDE_SPAWN_CHANCE;
}

function getTemplateByKind(kind) {
  return enemyTemplates.find((template) => template.kind === kind) ?? enemyTemplates[0];
}

function weightedRandom(items) {
  const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
  let roll = Math.random() * totalWeight;

  for (const item of items) {
    roll -= item.weight;

    if (roll <= 0) {
      return item;
    }
  }

  return items[0];
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function cancelEnemySpellcasting(enemy) {
  if (!enemy || enemy.hp <= 0 || enemy.state === EnemyState.DEAD) {
    return false;
  }

  const counterableTypes = new Set(["magic_missile", "dragon_breath"]);

  if (!counterableTypes.has(enemy.actionWindupType)) {
    return false;
  }

  const interruptedType = enemy.actionWindupType;

  enemy.actionWindupType = null;
  enemy.actionWindupRemaining = 0;
  enemy.state = EnemyState.IDLE;

  if (interruptedType === "magic_missile") {
    enemy.spellCooldown = ENEMY_SPELL_COOLDOWN;
  }

  if (interruptedType === "dragon_breath") {
    enemy.breathCooldown = DRAGON_BOSS_BREATH_COOLDOWN;
  }

  enemy.color = enemy.canCastMagicMissile ? "#664488" : enemy.kind === "dragon_boss" ? "#b33a1f" : "#884444";
  return true;
}

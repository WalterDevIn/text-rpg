import {
  TILE_SIZE,
  FEET_PER_TILE,
  RUN_SPEED_MULTIPLIER,
} from "./constants.js";

import { keys } from "./input.js";
import { player, getSpellSlotSummary } from "./player.js";
import { enemies } from "./enemy.js";
import { merchants } from "./merchant.js";
import { gameState, GameMode, ActionType, EnemyState } from "./state.js";
import { getDistance } from "./physics.js";
import { projectiles } from "./projectiles.js";
import { getItemDefinition } from "./items.js";

let output = null;
let input = null;
let enter = null;

export function setupUi({ outputElement, inputElement, enterButton }) {
  output = outputElement;
  input = inputElement;
  enter = enterButton;

  output.style.whiteSpace = "pre-wrap";
  output.style.fontFamily = "monospace";
  output.style.fontSize = "13px";
  output.style.lineHeight = "1.35";

  enter.addEventListener("click", submitInput);

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      submitInput();
    }
  });
}

export function updateHud() {
  if (!output) {
    return;
  }

  output.textContent = buildCharacterStatusText();
}

function buildCharacterStatusText() {
  const visibleEnemies = enemies.filter((enemy) => enemy.hp > 0 && enemy.state !== EnemyState.DEAD).length;
  const hiredAllies = merchants.filter((merchant) => merchant.hp > 0 && merchant.isHired).length;

  return [
    `PERSONAJE: ${player.name}`,
    `PG: ${player.hp}/${player.maxHp} | Oro: ${player.gold} po`,
    `Modo: ${getModeText()} | Tiempo: ${formatTime(gameState.elapsedTime)}`,
    `Posición: col ${(player.x / TILE_SIZE).toFixed(1)}, fila ${(player.y / TILE_SIZE).toFixed(1)}`,
    `Velocidad: ${keys.run ? "corriendo" : "normal"}`,
    `Ataque CD: ${player.attackCooldown.toFixed(1)}s | Conjuro CD: ${player.spellCooldown.toFixed(1)}s`,
    `Casteando: ${getCastingText()}`,
    `Escudo: ${player.shieldRemaining > 0 ? `${player.shieldRemaining.toFixed(1)}s` : "no"} | Detener tiempo: ${gameState.timeStopRemaining > 0 ? `${gameState.timeStopRemaining.toFixed(1)}s` : "no"}`,
    `Espacios de conjuro de mago nivel 20:`,
    getSpellSlotSummary(),
    `Inventario: ${getInventoryText()}`,
    `Amenazas vivas: ${visibleEnemies} | Aliadas contratadas: ${hiredAllies}`,
    `Mensaje: ${gameState.message}`,
  ].join("\n");
}


function getModeText() {
  if (gameState.mode === GameMode.ACTION_MENU) {
    return "menú detenido";
  }

  if (gameState.timeStopRemaining > 0) {
    return "tiempo detenido para todos menos para ti";
  }

  return "tiempo real";
}


function getInventoryText() {
  if (!player.inventory || player.inventory.length === 0) {
    return "vacío";
  }

  return player.inventory.map((item) => {
    const definition = getItemDefinition(item);
    const quantity = item.quantity > 1 ? ` x${item.quantity}` : "";
    return `${definition?.name ?? item.definitionId}${quantity}`;
  }).join(", ");
}

function getCastingText() {
  if (!player.isCasting) {
    return "no";
  }

  if (player.castingSpell === ActionType.CAST_CURE_WOUNDS) {
    return `Sanar heridas, ${player.castingRemaining.toFixed(1)}s`;
  }

  if (player.castingSpell === ActionType.CAST_TIME_STOP) {
    return `Detener el tiempo, ${player.castingRemaining.toFixed(1)}s`;
  }

  if (player.castingSpell === ActionType.CAST_MAGIC_MISSILE) {
    return `Misil mágico, ${player.castingRemaining.toFixed(1)}s`;
  }

  if (player.castingSpell === ActionType.CAST_BURNING_HANDS) {
    return `Manos ardientes, ${player.castingRemaining.toFixed(1)}s`;
  }

  if (player.castingSpell === ActionType.CAST_SHIELD) {
    return `Escudo, ${player.castingRemaining.toFixed(1)}s`;
  }

  if (player.castingSpell === ActionType.CAST_WALL_OF_FORCE) {
    return `Muro de fuerza, ${player.castingRemaining.toFixed(1)}s`;
  }

  return `${player.castingRemaining.toFixed(1)}s`;
}

function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function submitInput() {
  const command = input.value.trim().toLowerCase();
  input.value = "";

  if (command === "") return;

  if (command === "ayuda") {
    gameState.message = `Comandos:
ayuda
posicion
velocidad

Movimiento:
WASD físico = movimiento
flechas = movimiento alternativo
shift = correr
mantener f = detener tiempo y abrir acciones

Acciones:
1 = atacar
2 = sanar heridas
3 = detener el tiempo
4 = misil mágico
5 = manos ardientes
6 = escudo
7 = muro de fuerza

Inventario:
camina sobre un objeto para recogerlo
Atacar = elegir arma del inventario
Usar objeto = pociones y pergaminos`;
    return;
  }

  if (command === "posicion") {
    const col = player.x / TILE_SIZE;
    const row = player.y / TILE_SIZE;

    gameState.message = `Posición actual:
Columna: ${col.toFixed(2)}
Fila: ${row.toFixed(2)}`;
    return;
  }

  if (command === "velocidad") {
    gameState.message = `Velocidad:
Caminar: 6 casillas cada 6 segundos.
Correr: ${6 * RUN_SPEED_MULTIPLIER} casillas cada 6 segundos.
Una casilla representa 5 pies.`;
    return;
  }

  gameState.message = `No reconozco el comando: "${command}". Escribe "ayuda".`;
}
